Hello!

Thank you for downloading my recreation of John Hejduk’s Victims in Minecraft. To play in this world, all you need to do is:

*Install the World File*
1. open your Minecraft game files
	- Windows
		1. Press “Windows Key + R”
		2. Type “%appdata%.minecraft”
		3. Press “Enter”
	- MacOS
		1. Open Finder
		2. Press “Shift + Command + G”
		3. Type “~/Library/Application Support/minecraft,”
		4. Press “Return”
2. Navigate to the “saves” folder
3. Place the “Victims” folder in here

*Install the Resource Pack (Optional)*
- This resource pack is not necessary for the world to work, but I think it makes it nicer.
1. Open your Minecraft game files (see step 1 above)
2. Navigate to “resourcepacks” folder
3. Place the “resource-pack.zip” file in here

Enjoy :)
- Liam Vennerholm